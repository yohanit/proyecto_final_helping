package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout
import java.util.*
import kotlin.concurrent.schedule

class historial : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        val detalles: RelativeLayout = findViewById(R.id.detalles)
        val btnMore1: ImageButton = findViewById(R.id.imageViewMore1)
        btnMore1.setOnClickListener {
            detalles.visibility = View.VISIBLE
        }
        val btnMore2: ImageButton = findViewById(R.id.imageViewMore2)
        btnMore2.setOnClickListener {
            detalles.visibility = View.VISIBLE
        }
        val btnMore3: ImageButton = findViewById(R.id.imageViewMore3)
        btnMore3.setOnClickListener {
            detalles.visibility = View.VISIBLE
        }
        val btnMore4: ImageButton = findViewById(R.id.imageViewMore4)
        btnMore4.setOnClickListener {
            detalles.visibility = View.VISIBLE
        }
        val btnMore5: ImageButton = findViewById(R.id.imageViewMore5)
        btnMore5.setOnClickListener {
            detalles.visibility = View.VISIBLE
        }
        val btn2: ImageButton = findViewById(R.id.cerrar)
        btn2.setOnClickListener {
            detalles.visibility = View.GONE
        }
    }
}