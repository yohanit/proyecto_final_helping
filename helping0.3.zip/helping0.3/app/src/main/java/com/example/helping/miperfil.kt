package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast

class miperfil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_miperfil)
        val mediospago: Spinner = findViewById(R.id.mediospago)
        ArrayAdapter.createFromResource(
            this,
            R.array.mediospago,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            mediospago.adapter = adapter
        }

        val btn: Button = findViewById(R.id.guardar)
        btn.setOnClickListener {
            Toast.makeText(applicationContext,"Perfil guardado satisfactoriamente",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicios::class.java)
            startActivity(intent)
        }

        val btn2: Button = findViewById(R.id.historial)
        btn2.setOnClickListener {
            val intent: Intent = Intent(this, historial::class.java)
            startActivity(intent)
        }
    }
}