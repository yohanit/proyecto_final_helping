package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        val btn4: Button = findViewById(R.id.registrar)
        btn4.setOnClickListener {
            Toast.makeText(applicationContext,"Perfil creado satisfactoriamente", Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}

