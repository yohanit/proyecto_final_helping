package com.example.helping

import android.content.Context
import android.util.AttributeSet

import androidx.appcompat.widget.AppCompatImageView


class plantilla @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, desfStyleAttr: Int = 0
) : AppCompatImageView(context, attrs,desfStyleAttr) {


}