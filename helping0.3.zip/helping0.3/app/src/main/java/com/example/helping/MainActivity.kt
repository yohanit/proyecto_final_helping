package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_main)

        val btn: Button = findViewById(R.id.send)
        btn.setOnClickListener {
            val usuario = findViewById(R.id.correo) as EditText
            val password = findViewById(R.id.Password) as EditText
            val usuarioStr: String = usuario.text.toString()
            val passwordStr: String = password.text.toString()
            if(usuarioStr.trim().length>0){
                if(passwordStr.trim().length>0){
                    val intent: Intent = Intent(this, servicios::class.java)
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext,"Ingrese su contraseña", Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(applicationContext,"Ingrese su correo", Toast.LENGTH_SHORT).show()
            }
        }
        val btn2: Button = findViewById(R.id.registrar)
        btn2.setOnClickListener {
            val intent: Intent = Intent(this, registro::class.java)
            startActivity(intent)
        }

        val btn3: Button = findViewById(R.id.recuperarcontraseña)
        btn3.setOnClickListener {
            val intent: Intent = Intent(this, recuperacioncontrasena::class.java)
            startActivity(intent)
        }
    }

}


