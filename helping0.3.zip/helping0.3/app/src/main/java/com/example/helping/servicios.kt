package com.example.helping

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity

class servicios : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicios)
        val sMantenimientoBtn = findViewById<ImageButton>(R.id.mantenimiento)
        val sFormateoBtn = findViewById<ImageButton>(R.id.formateo)
        val sImpresoraBtn = findViewById<ImageButton>(R.id.impresora)
        val sInstalacionBtn = findViewById<ImageButton>(R.id.instalacion)
        val sActualizarSOBtn = findViewById<ImageButton>(R.id.actualizacion)
        //val btn: Button = findViewById(R.id.send)
        sMantenimientoBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioMantenimiento::class.java)
            startActivity(intent)
        }
        sFormateoBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, solicituDeServicioFormateo::class.java)
            startActivity(intent)
        }
        sImpresoraBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioImpresora::class.java)
            startActivity(intent)
        }
        sInstalacionBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioInstalacion::class.java)
            startActivity(intent)
        }
        sActualizarSOBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioActualizar_sistema::class.java)
            startActivity(intent)
        }
        val serviciocurso: RelativeLayout = findViewById(R.id.serviciocurso)
        val btnMore1: ImageButton = findViewById(R.id.servicioactivo)
        btnMore1.setOnClickListener {
            serviciocurso.visibility = View.VISIBLE
        }
        val btn2: ImageButton = findViewById(R.id.cerrarservicio)
        btn2.setOnClickListener {
            serviciocurso.visibility = View.GONE
        }
        val actionBar: android.app.ActionBar? = actionBar
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.app_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.perfil -> {
                val intent: Intent = Intent(this, miperfil::class.java)
                startActivity(intent)
                true
            }
            R.id.salir -> {
                val intent: Intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}