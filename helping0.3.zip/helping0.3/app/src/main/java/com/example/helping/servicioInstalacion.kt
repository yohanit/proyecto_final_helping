package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import java.util.*
import kotlin.concurrent.schedule

class servicioInstalacion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicio_instalacion)
        val confirmacion: RelativeLayout = findViewById(R.id.confirmacion)
        confirmacion.visibility = View.INVISIBLE
        val btn1: Button = findViewById(R.id.solicitud)
        btn1.setOnClickListener {
            confirmacion.visibility = View.VISIBLE
            val intent: Intent = Intent(this, servicios::class.java)
            Timer().schedule(3000){
                startActivity(intent)
            }

        }
    }
}