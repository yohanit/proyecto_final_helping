package com.example.helping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast

class prueba : AppCompatActivity () {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prueba)
        val sMantenimientoBtn = findViewById<ImageButton>(R.id.mantenimiento)
        val sFormateoBtn = findViewById<ImageButton>(R.id.formateo)
        val sImpresoraBtn = findViewById<ImageButton>(R.id.impresora)
        val sInstalacionBtn = findViewById<ImageButton>(R.id.instalacion)
        val sActualizarSOBtn = findViewById<ImageButton>(R.id.actualizacion)
        //val btn: Button = findViewById(R.id.send)
        sMantenimientoBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioMantenimiento::class.java)
            startActivity(intent)
        }
        sFormateoBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, solicituDeServicioFormateo::class.java)
            startActivity(intent)
        }
        sImpresoraBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioImpresora::class.java)
            startActivity(intent)
        }
        sInstalacionBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioInstalacion::class.java)
            startActivity(intent)
        }
        sActualizarSOBtn.setOnClickListener {
            //Toast.makeText(applicationContext,"Hola",Toast.LENGTH_SHORT).show()
            val intent: Intent = Intent(this, servicioActualizar_sistema::class.java)
            startActivity(intent)
        }

    }




}